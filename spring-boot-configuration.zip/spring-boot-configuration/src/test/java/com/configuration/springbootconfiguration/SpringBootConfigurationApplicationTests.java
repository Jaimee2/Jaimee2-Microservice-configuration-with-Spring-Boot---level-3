package com.configuration.springbootconfiguration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConfigurationApplicationTests {

	@Test
	void contextLoads() {
	}

}
